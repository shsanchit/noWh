# SWAAN Protected Runtime Module
# Proprietary and Confidential - Unauthorized copying or distribution is prohibited.
import zlib, base64
exec(zlib.decompress(base64.b64decode('eJxTVijOTM2NT81Lz8xL1Y+Pz8zLLImP1yuo5FJWCPZ09VXwzEvOTEnNK1FQU/BPS0vNK05VCM7MLc1JLMnMz1NwBevjAgBO+hf3')).decode('utf-8'))
