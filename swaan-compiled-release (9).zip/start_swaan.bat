@echo off
setlocal
cd /d "%~dp0"

echo ================================================================
echo   SWAAN SOAR Platform - Standalone Server
echo ================================================================
echo.

python --version >nul 2>&1
if errorlevel 1 goto :NO_PYTHON

if exist "venv\Scripts\python.exe" goto :RUN_SERVER

echo [1/3] Creating Python virtual environment (venv)...
python -m venv venv
if errorlevel 1 goto :VENV_FAILED

echo [2/3] Installing dependencies (this may take 1-2 minutes on first run)...
venv\Scripts\python.exe -m pip install --upgrade pip --quiet
venv\Scripts\pip.exe install -r requirements.txt
if errorlevel 1 goto :PIP_FAILED

echo [3/3] Initializing demo data...
venv\Scripts\python.exe seed.py --demo

:RUN_SERVER
echo.
echo ================================================================
echo   Launching SWAAN Protected Engine on http://localhost:8000
echo ================================================================
echo   Web UI:        http://localhost:8000
echo   API Docs:      http://localhost:8000/docs
echo   Default Login: admin / Password123!
echo ================================================================
echo.

start http://localhost:8000
venv\Scripts\python.exe main.py

if errorlevel 1 goto :SERVER_ERROR
goto :EOF

:NO_PYTHON
echo [ERROR] Python is not installed or not in Windows PATH!
echo.
echo Please install Python 3.11 or 3.12:
echo   1. Download installer: https://www.python.org/downloads/
echo   2. Run installer and CHECK: [x] "Add python.exe to PATH"
echo.
pause
exit /b 1

:VENV_FAILED
echo [ERROR] Failed to create virtual environment with Python.
pause
exit /b 1

:PIP_FAILED
echo [ERROR] Failed to install dependencies from requirements.txt.
pause
exit /b 1

:SERVER_ERROR
echo.
echo [ERROR] SWAAN server exited with an error.
pause
exit /b 1
