# SWAAN Protected Runtime Module
# Proprietary and Confidential - Unauthorized copying or distribution is prohibited.
import zlib, base64
exec(zlib.decompress(base64.b64decode('eJxFizEKgDAQBPu8YsHaR6SwsBIUHxDiJjlITgmH7zed3TIzO+FUScILi3aJpVFtzCxKN8GvswaTl7DSGQyixlolUyPB/5HuPhLCD2MSj83veGqwwZv7APC7I6U=')).decode('utf-8'))
