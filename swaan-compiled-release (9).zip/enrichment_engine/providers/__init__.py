# SWAAN Protected Runtime Module
# Proprietary and Confidential - Unauthorized copying or distribution is prohibited.
import zlib, base64
exec(zlib.decompress(base64.b64decode('eJxTVnDNK8pMzshNzSsBMtMz81IVHjVMUQgoyi/LTEktUnDOyQRKFXMBADwSD0Q=')).decode('utf-8'))
