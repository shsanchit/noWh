-- ══════════════════════════════════════════════════════════════════════
-- AgenticSOAR Intelligence Memory — PostgreSQL + pgvector Schema
-- ══════════════════════════════════════════════════════════════════════
-- 
-- Prerequisites:
--   CREATE EXTENSION IF NOT EXISTS vector;    -- pgvector
--   CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- trigram fuzzy search
--   CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
--
-- Designed for:
--   - AI-native SOC agent workflows
--   - Hybrid exact + semantic retrieval
--   - Campaign correlation and IOC pivoting
--   - Embedding versioning and regeneration
--   - Operational intelligence separated from AI memory
-- ══════════════════════════════════════════════════════════════════════

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ──────────────────────────────────────────────────────────────────────
-- 1. CAMPAIGNS (referenced by IOCs and Incidents)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS campaigns (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                TEXT NOT NULL,
    threat_actor        TEXT,
    description         TEXT,
    
    -- AI intelligence layer (separated from operational data)
    ai_summary          TEXT,
    embedding           vector(1536),
    embedding_model     TEXT DEFAULT 'text-embedding-3-small',
    embedding_version   INTEGER DEFAULT 1,
    
    -- MITRE context
    mitre_tactics       TEXT[],
    mitre_techniques    TEXT[],
    
    -- Clustering metadata
    confidence          FLOAT DEFAULT 0.0,
    auto_detected       BOOLEAN DEFAULT FALSE,
    detection_method    TEXT,                   -- "shared_iocs", "semantic_similarity", "analyst"
    
    -- Temporal intelligence
    first_seen          TIMESTAMPTZ DEFAULT NOW(),
    last_seen           TIMESTAMPTZ DEFAULT NOW(),
    incident_count      INTEGER DEFAULT 0,
    ioc_count           INTEGER DEFAULT 0,
    status              TEXT DEFAULT 'active',  -- active, dormant, attributed, closed
    
    tags                TEXT[],
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ──────────────────────────────────────────────────────────────────────
-- 2. IOC INTELLIGENCE MEMORY
-- ──────────────────────────────────────────────────────────────────────
-- Separated into: operational fields + AI memory fields

CREATE TABLE IF NOT EXISTS iocs (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- ── Operational Identity ──
    value               TEXT NOT NULL,
    ioc_type            TEXT NOT NULL,          -- ip, domain, url, sha256, md5, sha1, email
    
    -- ── Enrichment Intelligence (structured, exact-queryable) ──
    verdict             TEXT DEFAULT 'unknown', -- malicious, suspicious, clean, unknown
    confidence          INTEGER DEFAULT 0 CHECK (confidence BETWEEN 0 AND 100),
    risk_score          INTEGER DEFAULT 0 CHECK (risk_score BETWEEN 0 AND 100),
    
    -- ── Threat Context ──
    malware_families    TEXT[],                 -- {"Cobalt Strike", "Emotet"}
    threat_actors       TEXT[],                 -- {"APT29", "FIN7"}
    campaign_id         UUID REFERENCES campaigns(id) ON DELETE SET NULL,
    
    -- ── Network Intelligence (IPs/Domains) ──
    asn                 TEXT,
    asn_org             TEXT,
    country             TEXT,
    hosting_provider    TEXT,
    registrar           TEXT,
    
    -- ── File Intelligence (Hashes) ──
    file_names          TEXT[],
    file_types          TEXT[],
    file_size           BIGINT,
    
    -- ── MITRE Mapping ──
    mitre_tactics       TEXT[],
    mitre_techniques    TEXT[],
    
    -- ── Raw Enrichment (operational, NOT embedded) ──
    enrichment_sources  JSONB DEFAULT '{}',    -- {"virustotal": {...}, "abuseipdb": {...}}
    
    -- ── AI Intelligence Layer (separated, embedded) ──
    ai_summary          TEXT,                  -- AI-compressed behavioral summary
    embedding           vector(1536),
    embedding_model     TEXT DEFAULT 'text-embedding-3-small',
    embedding_version   INTEGER DEFAULT 1,
    
    -- ── Temporal Intelligence ──
    first_seen          TIMESTAMPTZ DEFAULT NOW(),
    last_seen           TIMESTAMPTZ DEFAULT NOW(),
    times_seen          INTEGER DEFAULT 1,
    incident_count      INTEGER DEFAULT 0,
    last_enriched       TIMESTAMPTZ,
    enrichment_ttl      INTERVAL DEFAULT '24 hours',
    
    -- ── Relationship Confidence ──
    actor_confidence    FLOAT DEFAULT 0.0,     -- confidence in threat_actors attribution
    campaign_confidence FLOAT DEFAULT 0.0,     -- confidence in campaign attribution
    
    -- ── Tags & Classification ──
    tags                TEXT[],                -- {"ransomware", "c2", "phishing", "tor_exit"}
    
    -- ── Lifecycle ──
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    
    -- Deduplication
    UNIQUE(value, ioc_type)
);

-- Exact lookup indexes (sub-ms)
CREATE INDEX IF NOT EXISTS idx_iocs_value ON iocs (value);
CREATE INDEX IF NOT EXISTS idx_iocs_value_trgm ON iocs USING gin (value gin_trgm_ops);  -- fuzzy search
CREATE INDEX IF NOT EXISTS idx_iocs_type ON iocs (ioc_type);
CREATE INDEX IF NOT EXISTS idx_iocs_verdict ON iocs (verdict);
CREATE INDEX IF NOT EXISTS idx_iocs_malware ON iocs USING GIN (malware_families);
CREATE INDEX IF NOT EXISTS idx_iocs_actors ON iocs USING GIN (threat_actors);
CREATE INDEX IF NOT EXISTS idx_iocs_tags ON iocs USING GIN (tags);
CREATE INDEX IF NOT EXISTS idx_iocs_mitre ON iocs USING GIN (mitre_techniques);
CREATE INDEX IF NOT EXISTS idx_iocs_campaign ON iocs (campaign_id);
CREATE INDEX IF NOT EXISTS idx_iocs_risk ON iocs (risk_score);
CREATE INDEX IF NOT EXISTS idx_iocs_last_seen ON iocs (last_seen);

-- Vector index for semantic search (HNSW — fast ANN)
CREATE INDEX IF NOT EXISTS idx_iocs_embedding ON iocs
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 256);


-- ──────────────────────────────────────────────────────────────────────
-- 3. INCIDENT INTELLIGENCE MEMORY
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incidents (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id         TEXT UNIQUE NOT NULL,     -- "INC-2CFB18A9"
    
    -- ── Classification ──
    incident_type       TEXT,                     -- "Ransomware", "Phishing", "Lateral Movement"
    severity_score      INTEGER CHECK (severity_score BETWEEN 0 AND 100),
    confidence          TEXT,                     -- "high", "medium", "low"
    status              TEXT DEFAULT 'open',      -- open, investigating, contained, resolved, closed, false_positive
    
    -- ── Source Alert (operational, NOT embedded) ──
    raw_alert           JSONB NOT NULL,
    source_siem         TEXT,
    alert_rule          TEXT,
    
    -- ── Affected Assets ──
    hostname            TEXT,
    src_ip              TEXT,
    dst_ip              TEXT,
    affected_user       TEXT,
    department          TEXT,
    asset_criticality   TEXT,
    
    -- ── MITRE ATT&CK ──
    mitre_tactics       TEXT[],
    mitre_techniques    TEXT[],
    kill_chain_phase    TEXT,                     -- "initial_access", "execution", "persistence"
    
    -- ── Business Impact ──
    risk_level          TEXT,                     -- Critical, High, Medium, Low
    business_impact     TEXT,
    data_at_risk        TEXT[],
    regulatory_flags    TEXT[],
    estimated_cost      TEXT,
    
    -- ── Agent Results (operational, NOT embedded) ──
    triage_result       JSONB,
    extracted_iocs      JSONB,
    enrichment_data     JSONB,
    asset_context       JSONB,
    logs_found          JSONB,
    siem_query          TEXT,
    mitre_mapping       JSONB,
    response_plan       JSONB,
    
    -- ── AI Intelligence Layer (separated, embedded) ──
    investigation_narrative TEXT,               -- AI-compressed investigation story
    ai_summary             TEXT,               -- One-paragraph summary
    final_report           TEXT,               -- Full markdown report
    embedding              vector(1536),
    embedding_model        TEXT DEFAULT 'text-embedding-3-small',
    embedding_version      INTEGER DEFAULT 1,
    
    -- ── Extracted Entities (for correlation) ──
    extracted_actors    TEXT[],                 -- threat actors mentioned
    extracted_malware   TEXT[],                 -- malware families
    extracted_cves      TEXT[],                 -- CVE-xxxx-xxxxx
    extracted_tools     TEXT[],                 -- tools used (mimikatz, psexec)
    
    -- ── Campaign Linkage ──
    campaign_id         UUID REFERENCES campaigns(id) ON DELETE SET NULL,
    campaign_confidence FLOAT DEFAULT 0.0,
    
    -- ── Temporal Intelligence ──
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    resolved_at         TIMESTAMPTZ,
    mttr_seconds        FLOAT,
    
    -- ── Analyst Actions ──
    analyst_notes       TEXT,
    analyst_verdict     TEXT,                    -- confirmed, false_positive, escalated
    steps_approved      INTEGER[],
    steps_rejected      INTEGER[],
    
    -- ── Relationship Confidence ──
    actor_confidence    FLOAT DEFAULT 0.0,
    
    tags                TEXT[],
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Exact indexes
CREATE INDEX IF NOT EXISTS idx_incidents_type ON incidents (incident_type);
CREATE INDEX IF NOT EXISTS idx_incidents_severity ON incidents (severity_score);
CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents (status);
CREATE INDEX IF NOT EXISTS idx_incidents_hostname ON incidents (hostname);
CREATE INDEX IF NOT EXISTS idx_incidents_created ON incidents (created_at);
CREATE INDEX IF NOT EXISTS idx_incidents_campaign ON incidents (campaign_id);
CREATE INDEX IF NOT EXISTS idx_incidents_mitre ON incidents USING GIN (mitre_techniques);
CREATE INDEX IF NOT EXISTS idx_incidents_tags ON incidents USING GIN (tags);
CREATE INDEX IF NOT EXISTS idx_incidents_actors ON incidents USING GIN (extracted_actors);
CREATE INDEX IF NOT EXISTS idx_incidents_malware ON incidents USING GIN (extracted_malware);
CREATE INDEX IF NOT EXISTS idx_incidents_verdict ON incidents (analyst_verdict);

-- Vector index for incident similarity search
CREATE INDEX IF NOT EXISTS idx_incidents_embedding ON incidents
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 256);


-- ──────────────────────────────────────────────────────────────────────
-- 4. IOC ↔ INCIDENT JUNCTION (Graph-like relationships)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incident_iocs (
    incident_id     UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    ioc_id          UUID NOT NULL REFERENCES iocs(id) ON DELETE CASCADE,
    context         TEXT,                       -- "source_ip", "c2_domain", "payload_hash"
    role            TEXT,                       -- "attacker", "victim", "infrastructure"
    confidence      FLOAT DEFAULT 1.0,         -- relationship confidence
    first_seen_in   TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (incident_id, ioc_id)
);

CREATE INDEX IF NOT EXISTS idx_incident_iocs_ioc ON incident_iocs (ioc_id);


-- ──────────────────────────────────────────────────────────────────────
-- 5. EXTRACTED ENTITIES (Dedicated entity layer)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS entities (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type     TEXT NOT NULL,             -- "threat_actor", "malware", "tool", "cve", "infrastructure"
    name            TEXT NOT NULL,             -- "APT29", "Cobalt Strike", "CVE-2024-1234"
    aliases         TEXT[],                    -- {"Cozy Bear", "The Dukes"}
    description     TEXT,
    
    -- AI intelligence
    ai_summary      TEXT,
    embedding       vector(1536),
    embedding_model TEXT DEFAULT 'text-embedding-3-small',
    embedding_version INTEGER DEFAULT 1,
    
    -- Context
    mitre_techniques TEXT[],
    related_malware TEXT[],
    related_actors  TEXT[],
    tags            TEXT[],
    
    -- Temporal
    first_seen      TIMESTAMPTZ DEFAULT NOW(),
    last_seen       TIMESTAMPTZ DEFAULT NOW(),
    incident_count  INTEGER DEFAULT 0,
    
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(entity_type, name)
);

CREATE INDEX IF NOT EXISTS idx_entities_type ON entities (entity_type);
CREATE INDEX IF NOT EXISTS idx_entities_name ON entities (name);
CREATE INDEX IF NOT EXISTS idx_entities_name_trgm ON entities USING gin (name gin_trgm_ops);

CREATE INDEX IF NOT EXISTS idx_entities_embedding ON entities
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 256);


-- ──────────────────────────────────────────────────────────────────────
-- 6. ENTITY ↔ INCIDENT JUNCTION
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS incident_entities (
    incident_id     UUID NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    entity_id       UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    role            TEXT,                       -- "attacker", "tool_used", "vulnerability_exploited"
    confidence      FLOAT DEFAULT 1.0,
    PRIMARY KEY (incident_id, entity_id)
);


-- ──────────────────────────────────────────────────────────────────────
-- 7. ANALYST KNOWLEDGE MEMORY
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS analyst_knowledge (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    knowledge_type  TEXT NOT NULL,              -- "finding", "playbook", "technique", "lesson", "sop"
    title           TEXT NOT NULL,
    content         TEXT NOT NULL,
    
    -- AI intelligence
    embedding       vector(1536),
    embedding_model TEXT DEFAULT 'text-embedding-3-small',
    embedding_version INTEGER DEFAULT 1,
    
    -- Context
    related_incident UUID REFERENCES incidents(id) ON DELETE SET NULL,
    related_campaign UUID REFERENCES campaigns(id) ON DELETE SET NULL,
    mitre_techniques TEXT[],
    tags            TEXT[],
    
    -- Source
    author          TEXT DEFAULT 'ai_agent',
    source_agent    TEXT,
    
    -- Temporal
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_knowledge_type ON analyst_knowledge (knowledge_type);
CREATE INDEX IF NOT EXISTS idx_knowledge_embedding ON analyst_knowledge
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 256);


-- ──────────────────────────────────────────────────────────────────────
-- 8. IOC ENRICHMENT HISTORY (audit trail)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS enrichment_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ioc_id          UUID NOT NULL REFERENCES iocs(id) ON DELETE CASCADE,
    source          TEXT NOT NULL,              -- "virustotal", "abuseipdb", "shodan"
    raw_response    JSONB,                     -- full provider response
    verdict         TEXT,
    confidence      INTEGER,
    enriched_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_enrichment_ioc ON enrichment_history (ioc_id);
CREATE INDEX IF NOT EXISTS idx_enrichment_source ON enrichment_history (source);


-- ──────────────────────────────────────────────────────────────────────
-- HELPER: Updated_at trigger
-- ──────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_iocs_updated_at ON iocs;
CREATE TRIGGER trg_iocs_updated_at BEFORE UPDATE ON iocs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_incidents_updated_at ON incidents;
CREATE TRIGGER trg_incidents_updated_at BEFORE UPDATE ON incidents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_campaigns_updated_at ON campaigns;
CREATE TRIGGER trg_campaigns_updated_at BEFORE UPDATE ON campaigns
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_entities_updated_at ON entities;
CREATE TRIGGER trg_entities_updated_at BEFORE UPDATE ON entities
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS trg_knowledge_updated_at ON analyst_knowledge;
CREATE TRIGGER trg_knowledge_updated_at BEFORE UPDATE ON analyst_knowledge
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ──────────────────────────────────────────────────────────────────────
-- 9. SIEM SIMULATOR SCHEMA
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS siem_offenses (
    offense_id          SERIAL PRIMARY KEY,
    offense_type        TEXT NOT NULL,
    offense_name        TEXT NOT NULL,
    severity            INTEGER DEFAULT 5, -- 1-10
    credibility         INTEGER DEFAULT 5, -- 1-10
    relevance           INTEGER DEFAULT 5, -- 1-10
    magnitude           INTEGER DEFAULT 5, -- 1-10
    status              TEXT DEFAULT 'OPEN', -- OPEN, ACTIVE, CLOSED, SUPPRESSED
    assigned_analyst    TEXT DEFAULT 'UNASSIGNED',
    source_ips          TEXT[] DEFAULT '{}',
    destination_ips     TEXT[] DEFAULT '{}',
    usernames           TEXT[] DEFAULT '{}',
    domains             TEXT[] DEFAULT '{}',
    hashes              TEXT[] DEFAULT '{}',
    mitre_mappings      TEXT[] DEFAULT '{}',
    malware_families    TEXT[] DEFAULT '{}',
    threat_actors       TEXT[] DEFAULT '{}',
    first_seen          TIMESTAMPTZ DEFAULT NOW(),
    last_seen           TIMESTAMPTZ DEFAULT NOW(),
    event_count         INTEGER DEFAULT 0,
    flow_count          INTEGER DEFAULT 0,
    log_sources         TEXT[] DEFAULT '{}',
    categories          TEXT[] DEFAULT '{}',
    tags                TEXT[] DEFAULT '{}',
    ai_summary          TEXT,
    enrichment_summary  TEXT,
    timeline            JSONB DEFAULT '[]'::jsonb,
    evidence            JSONB DEFAULT '[]'::jsonb,
    campaign_id         UUID,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS siem_events (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    offense_id          INTEGER REFERENCES siem_offenses(offense_id) ON DELETE SET NULL,
    timestamp           TIMESTAMPTZ DEFAULT NOW(),
    source_ip           TEXT,
    destination_ip      TEXT,
    source_port         INTEGER,
    destination_port    INTEGER,
    protocol            TEXT,
    username            TEXT,
    hostname            TEXT,
    process_name        TEXT,
    parent_process_name TEXT,
    command_line        TEXT,
    sha256              TEXT,
    md5                 TEXT,
    url                 TEXT,
    domain              TEXT,
    geo_country         TEXT,
    geo_city            TEXT,
    asn                 TEXT,
    asn_org             TEXT,
    ja3_fingerprint     TEXT,
    http_user_agent     TEXT,
    event_id            TEXT,
    severity            TEXT,
    log_source          TEXT NOT NULL,
    category            TEXT,
    raw_message         TEXT NOT NULL,
    normalized_fields   JSONB DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS siem_flows (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    offense_id          INTEGER REFERENCES siem_offenses(offense_id) ON DELETE SET NULL,
    timestamp           TIMESTAMPTZ DEFAULT NOW(),
    source_ip           TEXT NOT NULL,
    destination_ip      TEXT NOT NULL,
    source_port         INTEGER NOT NULL,
    destination_port    INTEGER NOT NULL,
    protocol            TEXT NOT NULL,
    bytes_sent          BIGINT DEFAULT 0,
    bytes_received      BIGINT DEFAULT 0,
    packets_sent        INTEGER DEFAULT 0,
    packets_received    INTEGER DEFAULT 0,
    application         TEXT DEFAULT 'Unknown',
    raw_flow            JSONB DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS siem_assets (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hostname            TEXT UNIQUE,
    ip_address          TEXT UNIQUE,
    mac_address         TEXT,
    owner               TEXT,
    department          TEXT,
    criticality         TEXT DEFAULT 'Medium', -- Low, Medium, High, Critical
    os                  TEXT,
    business_function   TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS siem_rules (
    rule_id             SERIAL PRIMARY KEY,
    name                TEXT UNIQUE NOT NULL,
    description         TEXT,
    category            TEXT NOT NULL,
    severity            INTEGER DEFAULT 5,
    rule_type           TEXT NOT NULL, -- Threshold, Sequence, Behavioral, etc.
    logic_definition    JSONB DEFAULT '{}'::jsonb,
    enabled             BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS siem_analyst_actions (
    id                  SERIAL PRIMARY KEY,
    offense_id          INTEGER REFERENCES siem_offenses(offense_id) ON DELETE CASCADE,
    timestamp           TIMESTAMPTZ DEFAULT NOW(),
    action_type         TEXT NOT NULL, -- Assign, Close, Escalate, Reopen, AddNote, AddTag, FalsePositive, IsolateHost, QuarantineAsset, SOARPlaybook
    analyst             TEXT NOT NULL,
    notes               TEXT,
    metadata            JSONB DEFAULT '{}'::jsonb
);

DROP TRIGGER IF EXISTS trg_siem_offenses_updated_at ON siem_offenses;
CREATE TRIGGER trg_siem_offenses_updated_at BEFORE UPDATE ON siem_offenses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Indexing for sub-millisecond AQL execution and search
CREATE INDEX IF NOT EXISTS idx_siem_events_timestamp ON siem_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_siem_events_offense_id ON siem_events(offense_id);
CREATE INDEX IF NOT EXISTS idx_siem_events_src_ip ON siem_events(source_ip);
CREATE INDEX IF NOT EXISTS idx_siem_events_dst_ip ON siem_events(destination_ip);
CREATE INDEX IF NOT EXISTS idx_siem_events_username ON siem_events(username);
CREATE INDEX IF NOT EXISTS idx_siem_events_hostname ON siem_events(hostname);
CREATE INDEX IF NOT EXISTS idx_siem_events_domain ON siem_events(domain);
CREATE INDEX IF NOT EXISTS idx_siem_events_sha256 ON siem_events(sha256);
CREATE INDEX IF NOT EXISTS idx_siem_events_category ON siem_events(category);
CREATE INDEX IF NOT EXISTS idx_siem_events_log_source ON siem_events(log_source);

CREATE INDEX IF NOT EXISTS idx_siem_flows_timestamp ON siem_flows(timestamp);
CREATE INDEX IF NOT EXISTS idx_siem_flows_offense_id ON siem_flows(offense_id);
CREATE INDEX IF NOT EXISTS idx_siem_flows_src_ip ON siem_flows(source_ip);
CREATE INDEX IF NOT EXISTS idx_siem_flows_dst_ip ON siem_flows(destination_ip);

CREATE INDEX IF NOT EXISTS idx_siem_offenses_status ON siem_offenses(status);
CREATE INDEX IF NOT EXISTS idx_siem_offenses_magnitude ON siem_offenses(magnitude);
CREATE INDEX IF NOT EXISTS idx_siem_offenses_assigned ON siem_offenses(assigned_analyst);

-- ──────────────────────────────────────────────────────────────────────
-- 10. ITSM TICKETS (ServiceNow-style mock)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS itsm_tickets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id       TEXT UNIQUE NOT NULL,
    incident_id     TEXT,
    short_description TEXT NOT NULL,
    description     TEXT,
    priority        TEXT DEFAULT 'P3',
    category        TEXT,
    subcategory     TEXT,
    assignment_group TEXT,
    assigned_to     TEXT,
    configuration_item TEXT,
    impact          TEXT,
    urgency         TEXT,
    state           TEXT DEFAULT 'New',
    caller_id       TEXT DEFAULT 'SOAR System',
    sla_due         TIMESTAMPTZ,
    resolved_at     TIMESTAMPTZ,
    resolution_notes TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_itsm_ticket_id ON itsm_tickets(ticket_id);
CREATE INDEX IF NOT EXISTS idx_itsm_incident ON itsm_tickets(incident_id);
CREATE INDEX IF NOT EXISTS idx_itsm_state ON itsm_tickets(state);
CREATE INDEX IF NOT EXISTS idx_itsm_priority ON itsm_tickets(priority);

DROP TRIGGER IF EXISTS trg_itsm_tickets_updated_at ON itsm_tickets;
CREATE TRIGGER trg_itsm_tickets_updated_at BEFORE UPDATE ON itsm_tickets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ──────────────────────────────────────────────────────────────────────
-- 11. NOTIFICATION LOG
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS notifications (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id     TEXT,
    channel         TEXT NOT NULL,
    recipient       TEXT NOT NULL,
    subject         TEXT,
    body            TEXT NOT NULL,
    status          TEXT DEFAULT 'queued',
    error_message   TEXT,
    metadata        JSONB DEFAULT '{}'::jsonb,
    sent_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_incident ON notifications(incident_id);
CREATE INDEX IF NOT EXISTS idx_notifications_channel ON notifications(channel);
CREATE INDEX IF NOT EXISTS idx_notifications_status ON notifications(status);

-- ──────────────────────────────────────────────────────────────────────
-- 12. MSSP TENANTS
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS mssp_tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       TEXT UNIQUE NOT NULL,
    tenant_name     TEXT NOT NULL,
    ip_ranges       TEXT[],
    domains         TEXT[],
    hostnames       TEXT[],
    contact_email   TEXT,
    contact_phone   TEXT,
    sla_tier        TEXT DEFAULT 'standard',
    escalation_contacts JSONB DEFAULT '[]'::jsonb,
    active          BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mssp_tenant_id ON mssp_tenants(tenant_id);

-- ──────────────────────────────────────────────────────────────────────
-- 13. CLASSIFICATION TAXONOMY
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS classification_taxonomy (
    id              SERIAL PRIMARY KEY,
    group_name      TEXT NOT NULL,
    category        TEXT NOT NULL,
    sub_category    TEXT NOT NULL,
    default_team    TEXT,
    default_priority TEXT DEFAULT 'P3',
    sla_hours       INTEGER DEFAULT 24,
    keywords        TEXT[],
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(group_name, category, sub_category)
);

-- ──────────────────────────────────────────────────────────────────────
-- 14. COMPLIANCE AUDITS (disabled but schema ready)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS compliance_audits (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id     TEXT,
    frameworks      TEXT[],
    findings        JSONB DEFAULT '[]'::jsonb,
    risk_rating     TEXT,
    requires_notification BOOLEAN DEFAULT FALSE,
    notification_deadline TIMESTAMPTZ,
    remediation_steps JSONB DEFAULT '[]'::jsonb,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_compliance_incident ON compliance_audits(incident_id);

-- ──────────────────────────────────────────────────────────────────────
-- 15. AGENT ERROR LOG
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS agent_error_log (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id     TEXT,
    agent_name      TEXT NOT NULL,
    tier            INTEGER,
    error_message   TEXT NOT NULL,
    traceback       TEXT,
    recovered       BOOLEAN DEFAULT FALSE,
    recovery_action TEXT,
    fallback_applied BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_agent_errors_incident ON agent_error_log(incident_id);
CREATE INDEX IF NOT EXISTS idx_agent_errors_agent ON agent_error_log(agent_name);


-- ──────────────────────────────────────────────────────────────────────
-- 16. USERS, ROLES, AND PERMISSIONS
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS roles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            TEXT UNIQUE NOT NULL,
    description     TEXT,
    permissions     TEXT[] NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username        TEXT UNIQUE NOT NULL,
    email           TEXT UNIQUE NOT NULL,
    password_hash   TEXT NOT NULL,
    salt            TEXT NOT NULL,
    first_name      TEXT,
    last_name       TEXT,
    role_name       TEXT NOT NULL REFERENCES roles(name) ON UPDATE CASCADE,
    is_active       BOOLEAN DEFAULT TRUE,
    last_login      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_sessions (
    token           TEXT PRIMARY KEY,
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_role ON users(role_name);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON user_sessions(expires_at);

-- ──────────────────────────────────────────────────────────────────────
-- 17. THREAT ADVISORIES
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS threat_advisories (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    source VARCHAR(100) NOT NULL,
    category VARCHAR(100) NOT NULL,
    severity VARCHAR(50) DEFAULT 'Low',
    summary TEXT,
    reference_url TEXT,
    published_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'unprocessed',
    bookmarked BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS advisory_iocs (
    id SERIAL PRIMARY KEY,
    advisory_id INT REFERENCES threat_advisories(id) ON DELETE CASCADE,
    ioc_type VARCHAR(50) NOT NULL,
    ioc_value TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_threat_advisories_source ON threat_advisories(source);
CREATE INDEX IF NOT EXISTS idx_threat_advisories_severity ON threat_advisories(severity);
CREATE INDEX IF NOT EXISTS idx_advisory_iocs_val ON advisory_iocs(ioc_value);


-- ──────────────────────────────────────────────────────────────────────
-- 10. NATIVE AGENTIC ITSM TICKETS
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS native_tickets (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id           TEXT UNIQUE NOT NULL,       -- "NTK-1001"
    title               TEXT NOT NULL,
    description         TEXT,
    category            TEXT,                       -- "access_management", "infrastructure", "software"
    assignment_group    TEXT,                       -- "SOC L1", "Infrastructure Team", etc.
    priority            TEXT DEFAULT 'P3',          -- P1, P2, P3, P4
    status              TEXT DEFAULT 'new',         -- new, assigning, diagnosing, action_pending, user_pending, resolved, closed
    assignee            TEXT,                       -- human or agent name
    created_by          TEXT DEFAULT 'system',
    incident_id         TEXT,                       -- linked incident if any
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS native_ticket_activities (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id           UUID REFERENCES native_tickets(id) ON DELETE CASCADE,
    agent_name          TEXT NOT NULL,              -- "Triage Agent", "Diagnosis Agent", "Remediation Agent"
    activity_type       TEXT NOT NULL,              -- "log", "diagnostic", "comment", "communication", "approval_request"
    content             TEXT NOT NULL,              -- JSON or raw text detailing action/findings
    status              TEXT DEFAULT 'completed',   -- pending_approval, approved, rejected, completed, failed
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_native_tickets_status ON native_tickets (status);
CREATE INDEX IF NOT EXISTS idx_native_ticket_activities_ticket ON native_ticket_activities (ticket_id);

-- ──────────────────────────────────────────────────────────────────────
-- 18. TELEMETRY & OBSERVABILITY ENGINE LOGS
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS agent_execution_logs (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id         TEXT NOT NULL,
    tenant_id           TEXT DEFAULT 'default',
    agent_name          TEXT NOT NULL,
    tier                INTEGER NOT NULL,
    status              TEXT NOT NULL,          -- running, complete, error, skipped
    model_name          TEXT,
    provider_name       TEXT,
    duration_seconds    DOUBLE PRECISION DEFAULT 0.0,
    input_tokens        INTEGER DEFAULT 0,
    output_tokens       INTEGER DEFAULT 0,
    total_tokens        INTEGER DEFAULT 0,
    context_chars       INTEGER DEFAULT 0,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_agent_exec_incident ON agent_execution_logs(incident_id);
CREATE INDEX IF NOT EXISTS idx_agent_exec_agent ON agent_execution_logs(agent_name);

CREATE TABLE IF NOT EXISTS tool_execution_logs (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id         TEXT NOT NULL,
    tenant_id           TEXT DEFAULT 'default',
    tool_name           TEXT NOT NULL,
    provider            TEXT NOT NULL,
    duration_seconds    DOUBLE PRECISION DEFAULT 0.0,
    status              TEXT NOT NULL,          -- complete, error
    error_message       TEXT,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tool_exec_incident ON tool_execution_logs(incident_id);
CREATE INDEX IF NOT EXISTS idx_tool_exec_tool ON tool_execution_logs(tool_name);


-- ──────────────────────────────────────────────────────────────────────
-- 10. LICENSING & SYSTEM CONTROL
-- ──────────────────────────────────────────────────────────────────────

-- License storage
CREATE TABLE IF NOT EXISTS licenses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    license_key     TEXT NOT NULL,
    license_id      TEXT UNIQUE NOT NULL,
    organization    TEXT NOT NULL,
    tier            TEXT NOT NULL DEFAULT 'community',
    max_seats       INTEGER DEFAULT 2,
    max_incidents   INTEGER DEFAULT 10,
    max_agents      INTEGER DEFAULT 5,
    features        TEXT[] DEFAULT '{}',
    issued_at       TIMESTAMPTZ NOT NULL,
    expires_at      TIMESTAMPTZ NOT NULL,
    activated_at    TIMESTAMPTZ DEFAULT NOW(),
    is_active       BOOLEAN DEFAULT TRUE,
    deactivated_at  TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- License audit log
CREATE TABLE IF NOT EXISTS license_audit_log (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    license_id      TEXT,
    action          TEXT NOT NULL,        -- 'activated', 'deactivated', 'expired', 'seat_denied', 'feature_denied', 'limit_reached'
    details         TEXT,
    performed_by    TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);


-- ══════════════════════════════════════════════════════════════════════
-- MULTI-TENANT ARCHITECTURE
-- ══════════════════════════════════════════════════════════════════════

-- ──────────────────────────────────────────────────────────────────────
-- T1. ORGANIZATIONS (Level 1 — Instances)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS organizations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id          TEXT UNIQUE NOT NULL,        -- slug: "secureops-mssp"
    display_name    TEXT NOT NULL,               -- "SecureOps MSSP"
    domain          TEXT,                        -- "secureops.com"

    -- Branding
    logo_url        TEXT,
    primary_color   TEXT DEFAULT '#4f46e5',
    accent_color    TEXT DEFAULT '#06b6d4',

    -- Limits & Billing
    plan            TEXT DEFAULT 'trial',        -- trial | starter | professional | enterprise
    max_tenants     INTEGER DEFAULT 3,
    max_seats_total INTEGER DEFAULT 10,
    data_region     TEXT DEFAULT 'us-east-1',
    billing_email   TEXT,

    -- Status
    status          TEXT DEFAULT 'active',       -- active | suspended | trial | cancelled
    trial_ends_at   TIMESTAMPTZ,

    metadata        JSONB DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_org_org_id ON organizations(org_id);
CREATE INDEX IF NOT EXISTS idx_org_domain ON organizations(domain);
CREATE INDEX IF NOT EXISTS idx_org_status ON organizations(status);

DROP TRIGGER IF EXISTS trg_organizations_updated_at ON organizations;
CREATE TRIGGER trg_organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ──────────────────────────────────────────────────────────────────────
-- T2. TENANTS (Level 2 — Sub-instances within an Org)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       TEXT UNIQUE NOT NULL,        -- "secureops-bank-a"
    org_id          TEXT NOT NULL REFERENCES organizations(org_id) ON DELETE CASCADE,
    display_name    TEXT NOT NULL,               -- "Bank-A"

    -- Limits (inherit or override org)
    max_seats       INTEGER DEFAULT 5,
    max_incidents_daily INTEGER DEFAULT 50,
    sla_tier        TEXT DEFAULT 'standard',     -- standard | premium | enterprise
    timezone        TEXT DEFAULT 'UTC',

    -- Config inheritance
    inherit_llm_config    BOOLEAN DEFAULT TRUE,  -- use org's LLM keys
    inherit_ti_config     BOOLEAN DEFAULT TRUE,  -- use org's TI keys
    inherit_itsm_config   BOOLEAN DEFAULT FALSE, -- tenants usually have own ITSM

    status          TEXT DEFAULT 'active',       -- active | suspended
    metadata        JSONB DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tenants_org ON tenants(org_id);
CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants(status);

DROP TRIGGER IF EXISTS trg_tenants_updated_at ON tenants;
CREATE TRIGGER trg_tenants_updated_at BEFORE UPDATE ON tenants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ──────────────────────────────────────────────────────────────────────
-- T3. TENANT SETTINGS (Per-org and per-tenant configuration)
-- ──────────────────────────────────────────────────────────────────────
-- Replaces soar_config.json for multi-tenant deployments.
-- Resolution order: tenant override → org default → platform default

CREATE TABLE IF NOT EXISTS tenant_settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      TEXT NOT NULL REFERENCES organizations(org_id) ON DELETE CASCADE,
    tenant_id   TEXT,                           -- NULL = org-level default
    category    TEXT NOT NULL,                  -- 'llm' | 'ti' | 'itsm' | 'siem' | 'messaging' | 'agents'
    config      JSONB NOT NULL DEFAULT '{}'::jsonb,
    updated_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, tenant_id, category)
);

CREATE INDEX IF NOT EXISTS idx_tenant_settings_org ON tenant_settings(org_id);
CREATE INDEX IF NOT EXISTS idx_tenant_settings_tenant ON tenant_settings(tenant_id);

-- ──────────────────────────────────────────────────────────────────────
-- T4. USAGE METRICS (Per-tenant billing metering)
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS usage_metrics (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id              TEXT NOT NULL,
    tenant_id           TEXT NOT NULL,
    metric_date         DATE NOT NULL DEFAULT CURRENT_DATE,

    -- Counters (incremented throughout the day)
    incidents_processed INTEGER DEFAULT 0,
    llm_input_tokens    BIGINT DEFAULT 0,
    llm_output_tokens   BIGINT DEFAULT 0,
    enrichments_run     INTEGER DEFAULT 0,
    tickets_created     INTEGER DEFAULT 0,
    notifications_sent  INTEGER DEFAULT 0,
    api_calls           INTEGER DEFAULT 0,

    -- Cost tracking
    estimated_cost_usd  NUMERIC(10,4) DEFAULT 0,

    created_at          TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, tenant_id, metric_date)
);

CREATE INDEX IF NOT EXISTS idx_usage_org_date ON usage_metrics(org_id, metric_date);
CREATE INDEX IF NOT EXISTS idx_usage_tenant_date ON usage_metrics(tenant_id, metric_date);


-- ──────────────────────────────────────────────────────────────────────
-- T5. ORG MODULE ACCESS (Per-org feature module control)
-- ──────────────────────────────────────────────────────────────────────
-- Granular control over which platform modules each organization can access.
-- Core modules (incidents, auth, core) are always implicitly enabled.
-- Resolution order: if an org has NO rows here → all modules enabled (grandfather).

CREATE TABLE IF NOT EXISTS org_module_access (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      TEXT NOT NULL REFERENCES organizations(org_id) ON DELETE CASCADE,
    module_id   TEXT NOT NULL,              -- 'incidents', 'siem', 'enrichment', etc.
    enabled     BOOLEAN DEFAULT TRUE,
    enabled_by  TEXT,                       -- username who toggled it
    enabled_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, module_id)
);

CREATE INDEX IF NOT EXISTS idx_org_modules_org ON org_module_access(org_id);
CREATE INDEX IF NOT EXISTS idx_org_modules_module ON org_module_access(module_id);

-- ──────────────────────────────────────────────────────────────────────
-- T6. SYSTEM ISSUES & SUPPORT TELEMETRY
-- ──────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS system_issues (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    issue_id            VARCHAR(64) UNIQUE NOT NULL,
    title               VARCHAR(255) NOT NULL,
    description         TEXT,
    category            VARCHAR(64) DEFAULT 'Bug',
    severity            VARCHAR(32) DEFAULT 'Medium',
    reporter_user       VARCHAR(128),
    reporter_email      VARCHAR(255),
    system_telemetry    JSONB DEFAULT '{}',
    status              VARCHAR(32) DEFAULT 'Open',
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_system_issues_created ON system_issues(created_at DESC);

