# SWAAN SOAR Platform - GitHub Auto-Updater
param (
    [string]$Repo = "shsanchit/noWh"
)

$ErrorActionPreference = "Stop"

Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  SWAAN SOAR Platform - GitHub Auto-Updater" -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Checking for latest release from GitHub ($Repo)..." -ForegroundColor Yellow

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

try {
    $apiUrl = "https://api.github.com/repos/$Repo/releases/latest"
    $release = Invoke-RestMethod -Uri $apiUrl -Headers @{ "User-Agent" = "SWAAN-Updater" }
    $asset = $release.assets | Where-Object { $_.name -like "*swaan-compiled-release.zip*" } | Select-Object -First 1

    if (-not $asset) {
        Write-Host "[ERROR] No release asset found in latest GitHub release." -ForegroundColor Red
        Exit 1
    }

    Write-Host ("Downloading update: " + $release.tag_name + " (" + $asset.name + ")...") -ForegroundColor Green
    $tempZip = Join-Path $scriptDir "update_temp.zip"
    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $tempZip

    Write-Host "Extracting update files..." -ForegroundColor Green
    Expand-Archive -Path $tempZip -DestinationPath $scriptDir -Force
    Remove-Item $tempZip -Force

    Write-Host "[OK] Files updated successfully!" -ForegroundColor Green
} catch {
    Write-Host ("[ERROR] Update failed: " + $_.Exception.Message) -ForegroundColor Red
    Exit 1
}

$venvPython = Join-Path $scriptDir "venv\Scripts\python.exe"
$venvPip = Join-Path $scriptDir "venv\Scripts\pip.exe"

if (Test-Path $venvPython) {
    Write-Host "[1/2] Updating Python packages..." -ForegroundColor Cyan
    & $venvPip install -r (Join-Path $scriptDir "requirements.txt") --quiet
    Write-Host "[2/2] Updating database schemas and demo dataset..." -ForegroundColor Cyan
    & $venvPython (Join-Path $scriptDir "seed.pyc") --demo
}

Write-Host ""
Write-Host "================================================================" -ForegroundColor Green
Write-Host "  SWAAN successfully updated to the latest version!" -ForegroundColor Green
Write-Host "================================================================" -ForegroundColor Green
Write-Host ""
