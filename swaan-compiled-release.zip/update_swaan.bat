@echo off
setlocal enabledelayedexpansion
title SWAAN SOAR Platform - Updater
cd /d "%~dp0"

echo ================================================================
echo   SWAAN SOAR Platform - GitHub Auto-Updater
echo ================================================================
echo.

set GITHUB_REPO=shsanchit/SWAAN-v4
if not "%~1"=="" set GITHUB_REPO=%~1

echo Checking for latest protected release from GitHub (%GITHUB_REPO%)...

powershell -Command ^
    "$repo = '%GITHUB_REPO%';" ^
    "$url = 'https://api.github.com/repos/' + $repo + '/releases/latest';" ^
    "try {" ^
    "    $release = Invoke-RestMethod -Uri $url -Headers @{'User-Agent'='SWAAN-Updater'};" ^
    "    $asset = $release.assets | Where-Object { $_.name -like '*swaan-compiled-release.zip*' } | Select-Object -First 1;" ^
    "    if (-not $asset) { Write-Host '[ERROR] No release zip found in latest release.' -ForegroundColor Red; exit 1; }" ^
    "    Write-Host ('Downloading update: ' + $release.tag_name + ' (' + $asset.name + ')...') -ForegroundColor Cyan;" ^
    "    Invoke-WebRequest -Uri $asset.browser_download_url -OutFile 'update_temp.zip';" ^
    "    Write-Host 'Extracting update files...' -ForegroundColor Green;" ^
    "    Expand-Archive -Path 'update_temp.zip' -DestinationPath '.' -Force;" ^
    "    Remove-Item 'update_temp.zip' -Force;" ^
    "    Write-Host '[OK] Update applied successfully!' -ForegroundColor Green;" ^
    "} catch {" ^
    "    Write-Host ('[ERROR] Failed to download update: ' + $_.Exception.Message) -ForegroundColor Red;" ^
    "    exit 1;" ^
    "}"

if errorlevel 1 (
    echo.
    echo Update failed. Please check your internet connection or GitHub repository settings.
    pause
    exit /b 1
)

echo.
echo [1/2] Updating Python dependencies (if changed)...
if exist "venv\Scripts\python.exe" (
    call venv\Scripts\pip install -r requirements.txt --quiet
)

echo [2/2] Updating database schemas and demo dataset...
if exist "venv\Scripts\python.exe" (
    venv\Scripts\python seed.pyc --demo
)

echo.
echo ================================================================
echo   SWAAN successfully updated to the latest version!
echo ================================================================
echo.
pause
