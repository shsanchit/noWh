@echo off
title SWAAN SOAR Platform - Secure Standalone
cd /d "%~dp0"

echo ================================================================
echo   SWAAN SOAR Platform - Protected Binary Edition
echo ================================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.11 or 3.12 (check "Add python.exe to PATH").
    pause
    exit /b 1
)

if not exist "venv\Scripts\python.exe" (
    echo [1/2] Initializing virtual environment...
    python -m venv venv
    call venv\Scripts\pip install -r requirements.txt
)

echo [2/2] Launching SWAAN Protected Engine...
echo.
echo   Web UI:        http://localhost:8000
echo   API Docs:      http://localhost:8000/docs
echo   Default Login: admin / Password123!
echo.
echo ================================================================
echo.

venv\Scripts\python main.pyc
pause
